This hit data has some issues.
The baseline didn't go back all the way so the model might confuse it.